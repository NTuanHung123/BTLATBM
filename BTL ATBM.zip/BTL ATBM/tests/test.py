import json
import time
import uuid

import pytest
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from secure_replication import SecureReplication


@pytest.fixture
def service(tmp_path):
    # Mỗi test dùng thư mục riêng, không ảnh hưởng dữ liệu thật.
    return SecureReplication(tmp_path)


def upload_sample(service):
    return service.upload(
        b"Noi dung bai tap lon an toan bao mat",
        "baocao.txt",
        uuid.uuid4().hex,
        int(time.time()),
    )


def test_upload_to_three_clouds_and_separate_metadata(service):
    file_id = upload_sample(service)

    for cloud_name in service.cloud_names:
        cipher_path = service.storage_dir / cloud_name / f"{file_id}.bin"
        metadata_path = service.storage_dir / cloud_name / f"{file_id}.json"

        assert cipher_path.exists()
        assert metadata_path.exists()

        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        assert metadata["cloud_name"] == cloud_name
        assert metadata["algorithm"] == "AES-256-GCM"


def test_compare_hash_and_tag_between_clouds(service):
    file_id = upload_sample(service)
    result = service.compare_clouds(file_id)

    assert result["all_healthy"] is True
    assert result["same_hash_tag"] is True
    assert result["healthy_count"] == 3


def test_detect_tampered_cloud(service):
    file_id = upload_sample(service)
    service.tamper(file_id, "cloud_a")

    assert service.check_cloud(file_id, "cloud_a")["status"] == "CORRUPTED"
    assert service.compare_clouds(file_id)["all_healthy"] is False


def test_detect_missing_cloud(service):
    file_id = upload_sample(service)
    service.delete_copy(file_id, "cloud_a")

    assert service.check_cloud(file_id, "cloud_a")["status"] == "MISSING"


def test_download_from_backup_cloud(service):
    file_id = upload_sample(service)
    service.tamper(file_id, "cloud_a")

    # Cloud A bị sửa nên hệ thống phải tự chuyển sang Cloud B.
    data, filename, used_cloud = service.download(file_id, "cloud_a")

    assert data == b"Noi dung bai tap lon an toan bao mat"
    assert filename == "baocao.txt"
    assert used_cloud == "cloud_b"


def test_replay_is_rejected(service):
    request_id = uuid.uuid4().hex
    now = int(time.time())

    service.upload(b"lan 1", "a.txt", request_id, now)

    with pytest.raises(ValueError, match="replay"):
        service.upload(b"lan 2", "b.txt", request_id, now)


def test_expired_request_is_rejected(service):
    old_timestamp = int(time.time()) - 1000

    with pytest.raises(ValueError, match="hết hạn"):
        service.upload(
            b"du lieu cu",
            "cu.txt",
            uuid.uuid4().hex,
            old_timestamp,
        )


def test_wrong_key_cannot_decrypt(service):
    file_id = upload_sample(service)

    # Thay khóa đúng bằng khóa ngẫu nhiên khác để mô phỏng dùng sai khóa.
    service.key = AESGCM.generate_key(bit_length=256)

    with pytest.raises(ValueError, match="Không còn cloud hợp lệ"):
        service.download(file_id)


def test_cloud_status_is_written_to_log(service):
    file_id = upload_sample(service)
    service.check_integrity(file_id)

    log_text = service.log_path.read_text(encoding="utf-8")
    assert "TRANG_THAI_CLOUD" in log_text
    assert "cloud=cloud_a status=HEALTHY" in log_text
    assert "cloud=cloud_b status=HEALTHY" in log_text
    assert "cloud=cloud_c status=HEALTHY" in log_text
