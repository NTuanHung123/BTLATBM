from __future__ import annotations

import os
import secrets
import time
import uuid
from io import BytesIO

from flask import Flask, flash, redirect, render_template, request, send_file, url_for
from werkzeug.utils import secure_filename

from secure_replication import SecureReplication

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(32))
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # Tối đa 10 MB

# Khởi tạo hệ thống sao chép an toàn.
service = SecureReplication()


@app.get("/")
def index():
    documents = []

    for document in service.list_documents():
        item = dict(document)
        comparison = service.compare_clouds(document["file_id"])
        item["clouds"] = comparison["results"]
        item["comparison"] = comparison
        documents.append(item)

    return render_template(
        "index.html",
        documents=documents,
        cloud_names=service.cloud_names,
        logs=service.get_recent_logs(20),
        request_id=uuid.uuid4().hex,
        request_timestamp=int(time.time()),
    )


@app.post("/upload")
def upload():
    uploaded_file = request.files.get("file")
    if not uploaded_file or not uploaded_file.filename:
        flash("Bạn chưa chọn tài liệu.", "error")
        return redirect(url_for("index"))

    try:
        filename = secure_filename(uploaded_file.filename) or "tai_lieu.bin"
        service.upload(
            uploaded_file.read(),
            filename,
            request.form.get("request_id", ""),
            int(request.form.get("request_timestamp", "0")),
        )
        flash("Đã mã hóa và tải tài liệu lên 3 cloud thành công.", "success")
    except Exception as exc:
        flash(str(exc), "error")

    return redirect(url_for("index"))


@app.get("/download/<file_id>")
def download(file_id: str):
    try:
        data, filename, used_cloud = service.download(
            file_id,
            request.args.get("cloud"),
        )
        response = send_file(
            BytesIO(data),
            as_attachment=True,
            download_name=filename,
            mimetype="application/octet-stream",
        )
        response.headers["X-Used-Cloud"] = used_cloud
        return response
    except Exception as exc:
        flash(str(exc), "error")
        return redirect(url_for("index"))


@app.post("/check/<file_id>")
def check(file_id: str):
    try:
        result = service.compare_clouds(file_id)
        category = "success" if result["all_healthy"] else "warning"
        flash(result["summary"], category)
    except Exception as exc:
        flash(str(exc), "error")
    return redirect(url_for("index"))


@app.post("/tamper/<file_id>/<cloud_name>")
def tamper(file_id: str, cloud_name: str):
    try:
        service.tamper(file_id, cloud_name)
        flash(f"Đã mô phỏng sửa dữ liệu tại {cloud_name}.", "warning")
    except Exception as exc:
        flash(str(exc), "error")
    return redirect(url_for("index"))


@app.post("/delete/<file_id>/<cloud_name>")
def delete_copy(file_id: str, cloud_name: str):
    try:
        service.delete_copy(file_id, cloud_name)
        flash(f"Đã mô phỏng mất bản sao tại {cloud_name}.", "warning")
    except Exception as exc:
        flash(str(exc), "error")
    return redirect(url_for("index"))


@app.errorhandler(413)
def too_large(_error):
    flash("Tài liệu vượt quá giới hạn 10 MB.", "error")
    return redirect(url_for("index"))


if __name__ == "__main__":
    debug_mode = os.environ.get("FLASK_DEBUG") == "1"
    app.run(debug=debug_mode, host="127.0.0.1", port=5000)
