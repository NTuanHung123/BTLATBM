from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class SecureReplication:
    """Giả lập mã hóa và sao chép tài liệu lên 3 cloud."""

    def __init__(self, base_dir: str | Path | None = None):
        self.base_dir = Path(base_dir or Path(__file__).resolve().parent)
        self.storage_dir = self.base_dir / "storage"
        self.instance_dir = self.base_dir / "instance"
        self.logs_dir = self.base_dir / "logs"
        self.cloud_names = ["cloud_a", "cloud_b", "cloud_c"]

        # Tự tạo thư mục chạy lần đầu, người dùng không cần tạo tay.
        for cloud_name in self.cloud_names:
            (self.storage_dir / cloud_name).mkdir(parents=True, exist_ok=True)
        self.instance_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)

        self.index_path = self.instance_dir / "documents.json"
        self.requests_path = self.instance_dir / "used_requests.json"
        self.key_path = self.instance_dir / "master.key"
        self.log_path = self.logs_dir / "system.log"

        self.key = self._load_or_create_key()
        self.logger = self._create_logger()

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _sha256(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def _b64(data: bytes) -> str:
        return base64.b64encode(data).decode("ascii")

    @staticmethod
    def _from_b64(value: str) -> bytes:
        return base64.b64decode(value.encode("ascii"))

    def _load_json(self, path: Path, default):
        if not path.exists():
            return default
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return default

    def _save_json(self, path: Path, data) -> None:
        path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _load_or_create_key(self) -> bytes:
        # Khóa AES-256 được sinh tự động, không hard-code trong source code.
        if self.key_path.exists():
            key = self.key_path.read_bytes()
            if len(key) != 32:
                raise ValueError("Khóa bí mật không hợp lệ.")
            return key

        key = AESGCM.generate_key(bit_length=256)
        self.key_path.write_bytes(key)
        return key

    def _create_logger(self) -> logging.Logger:
        logger = logging.getLogger(f"secure_replication_{id(self)}")
        logger.setLevel(logging.INFO)
        logger.propagate = False

        if not logger.handlers:
            handler = logging.FileHandler(self.log_path, encoding="utf-8")
            handler.setFormatter(
                logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
            )
            logger.addHandler(handler)

        return logger

    def _cloud_dir(self, cloud_name: str) -> Path:
        if cloud_name not in self.cloud_names:
            raise ValueError("Cloud không hợp lệ.")
        return self.storage_dir / cloud_name

    def _cipher_path(self, file_id: str, cloud_name: str) -> Path:
        return self._cloud_dir(cloud_name) / f"{file_id}.bin"

    def _metadata_path(self, file_id: str, cloud_name: str) -> Path:
        return self._cloud_dir(cloud_name) / f"{file_id}.json"

    def _get_document(self, file_id: str) -> dict:
        for document in self.list_documents():
            if document["file_id"] == file_id:
                return document
        raise ValueError("Không tìm thấy tài liệu.")

    def _check_replay(self, request_id: str, request_timestamp: int) -> None:
        """Từ chối request cũ hoặc request_id đã được dùng."""
        if not request_id:
            raise ValueError("Thiếu mã yêu cầu request_id.")

        if abs(int(time.time()) - request_timestamp) > 300:
            self.logger.warning(
                "TU_CHOI_REPLAY request_id=%s ly_do=het_han", request_id
            )
            raise ValueError("Yêu cầu đã hết hạn.")

        used_requests = self._load_json(self.requests_path, [])
        if request_id in used_requests:
            self.logger.warning(
                "TU_CHOI_REPLAY request_id=%s ly_do=trung_lap", request_id
            )
            raise ValueError("Phát hiện yêu cầu bị gửi lại (replay).")

        used_requests.append(request_id)
        self._save_json(self.requests_path, used_requests[-1000:])

    def upload(
        self,
        file_bytes: bytes,
        original_name: str,
        request_id: str,
        request_timestamp: int,
    ) -> str:
        """Mã hóa tài liệu rồi sao chép lên 3 cloud."""
        if not file_bytes:
            raise ValueError("Tài liệu rỗng, không thể tải lên.")

        self._check_replay(request_id, request_timestamp)

        file_id = uuid.uuid4().hex
        uploaded_at = self._now_iso()

        # AES-GCM: mỗi tài liệu dùng nonce mới 12 byte.
        nonce = os.urandom(12)
        aad = f"{file_id}|{original_name}".encode("utf-8")
        ciphertext = AESGCM(self.key).encrypt(nonce, file_bytes, aad)

        ciphertext_hash = self._sha256(ciphertext)
        plaintext_hash = self._sha256(file_bytes)
        tag_b64 = self._b64(ciphertext[-16:])
        nonce_b64 = self._b64(nonce)

        document = {
            "file_id": file_id,
            "original_name": original_name,
            "uploaded_at": uploaded_at,
            "file_size": len(file_bytes),
            "plaintext_sha256": plaintext_hash,
            "ciphertext_sha256": ciphertext_hash,
            "nonce_b64": nonce_b64,
            "tag_b64": tag_b64,
        }

        # Lưu chỉ mục trung tâm để quản lý danh sách tài liệu.
        documents = self.list_documents()
        documents.append(document)
        self._save_json(self.index_path, documents)

        # Mỗi cloud lưu một bản mã hóa và một metadata riêng.
        for cloud_name in self.cloud_names:
            cloud_metadata = {
                "file_id": file_id,
                "original_name": original_name,
                "cloud_name": cloud_name,
                "uploaded_at": uploaded_at,
                "algorithm": "AES-256-GCM",
                "nonce_b64": nonce_b64,
                "ciphertext_sha256": ciphertext_hash,
                "tag_b64": tag_b64,
                "ciphertext_size": len(ciphertext),
            }

            self._cipher_path(file_id, cloud_name).write_bytes(ciphertext)
            self._save_json(
                self._metadata_path(file_id, cloud_name),
                cloud_metadata,
            )
            self.logger.info(
                "TAI_LEN file_id=%s cloud=%s trang_thai=THANH_CONG",
                file_id,
                cloud_name,
            )

        return file_id

    def list_documents(self) -> list[dict]:
        return self._load_json(self.index_path, [])

    def check_cloud(self, file_id: str, cloud_name: str) -> dict:
        """Kiểm tra một bản sao có bị mất hoặc bị sửa hay không."""
        document = self._get_document(file_id)
        cipher_path = self._cipher_path(file_id, cloud_name)
        metadata_path = self._metadata_path(file_id, cloud_name)

        if not cipher_path.exists() or not metadata_path.exists():
            return {
                "cloud": cloud_name,
                "status": "MISSING",
                "detail": "Thiếu file mã hóa hoặc metadata",
            }

        try:
            ciphertext = cipher_path.read_bytes()
            metadata = self._load_json(metadata_path, {})
        except OSError:
            return {
                "cloud": cloud_name,
                "status": "CORRUPTED",
                "detail": "Không đọc được dữ liệu",
            }

        actual_hash = self._sha256(ciphertext)
        actual_tag = self._b64(ciphertext[-16:]) if len(ciphertext) >= 16 else ""

        checks = [
            metadata.get("file_id") == file_id,
            metadata.get("cloud_name") == cloud_name,
            metadata.get("algorithm") == "AES-256-GCM",
            metadata.get("nonce_b64") == document["nonce_b64"],
            metadata.get("ciphertext_sha256") == document["ciphertext_sha256"],
            metadata.get("tag_b64") == document["tag_b64"],
            metadata.get("ciphertext_size") == len(ciphertext),
            actual_hash == document["ciphertext_sha256"],
            actual_tag == document["tag_b64"],
        ]

        if all(checks):
            return {
                "cloud": cloud_name,
                "status": "HEALTHY",
                "detail": "Bản sao an toàn và hợp lệ",
                "hash": actual_hash,
                "tag": actual_tag,
            }

        return {
            "cloud": cloud_name,
            "status": "CORRUPTED",
            "detail": "Dữ liệu hoặc metadata đã bị sửa đổi",
            "hash": actual_hash,
            "tag": actual_tag,
        }

    def check_integrity(self, file_id: str) -> list[dict]:
        """Kiểm tra và ghi log trạng thái riêng của từng cloud."""
        results = []
        for cloud_name in self.cloud_names:
            result = self.check_cloud(file_id, cloud_name)
            results.append(result)
            self.logger.info(
                "TRANG_THAI_CLOUD file_id=%s cloud=%s status=%s",
                file_id,
                cloud_name,
                result["status"],
            )
        return results

    def compare_clouds(self, file_id: str) -> dict:
        """So sánh hash/tag giữa các cloud và tổng hợp trạng thái."""
        results = self.check_integrity(file_id)
        healthy = [item for item in results if item["status"] == "HEALTHY"]

        hash_tag_pairs = {(item["hash"], item["tag"]) for item in healthy}
        same_hash_tag = len(hash_tag_pairs) <= 1
        all_healthy = len(healthy) == len(self.cloud_names)

        if all_healthy and same_hash_tag:
            summary = "3/3 cloud an toàn, hash và tag hoàn toàn đồng nhất."
        else:
            bad_count = len(self.cloud_names) - len(healthy)
            summary = f"Phát hiện {bad_count} cloud bị mất hoặc bị sửa đổi."

        self.logger.info(
            "SO_SANH_CLOUD file_id=%s healthy=%s/%s hash_tag_dong_nhat=%s",
            file_id,
            len(healthy),
            len(self.cloud_names),
            same_hash_tag,
        )

        return {
            "results": results,
            "healthy_count": len(healthy),
            "all_healthy": all_healthy,
            "same_hash_tag": same_hash_tag,
            "summary": summary,
        }

    def download(self, file_id: str, preferred_cloud: str | None = None):
        """Tải từ cloud ưu tiên; lỗi thì tự chuyển sang cloud dự phòng."""
        document = self._get_document(file_id)
        order = list(self.cloud_names)

        if preferred_cloud in self.cloud_names:
            order.remove(preferred_cloud)
            order.insert(0, preferred_cloud)

        for cloud_name in order:
            status = self.check_cloud(file_id, cloud_name)
            if status["status"] != "HEALTHY":
                self.logger.warning(
                    "BO_QUA_CLOUD file_id=%s cloud=%s status=%s",
                    file_id,
                    cloud_name,
                    status["status"],
                )
                continue

            ciphertext = self._cipher_path(file_id, cloud_name).read_bytes()
            nonce = self._from_b64(document["nonce_b64"])
            aad = f"{file_id}|{document['original_name']}".encode("utf-8")

            try:
                plaintext = AESGCM(self.key).decrypt(nonce, ciphertext, aad)
            except InvalidTag:
                self.logger.warning(
                    "GIAI_MA_THAT_BAI file_id=%s cloud=%s",
                    file_id,
                    cloud_name,
                )
                continue

            if self._sha256(plaintext) != document["plaintext_sha256"]:
                self.logger.warning(
                    "SAI_HASH_FILE_GOC file_id=%s cloud=%s",
                    file_id,
                    cloud_name,
                )
                continue

            self.logger.info(
                "TAI_THANH_CONG file_id=%s cloud=%s",
                file_id,
                cloud_name,
            )
            return plaintext, document["original_name"], cloud_name

        raise ValueError("Không còn cloud hợp lệ để tải tài liệu.")

    def tamper(self, file_id: str, cloud_name: str) -> None:
        """Mô phỏng kẻ tấn công sửa một bit trong ciphertext."""
        path = self._cipher_path(file_id, cloud_name)
        if not path.exists():
            raise ValueError("Cloud này không còn bản sao tài liệu.")

        data = bytearray(path.read_bytes())
        if not data:
            raise ValueError("File mã hóa rỗng.")

        data[len(data) // 2] ^= 1
        path.write_bytes(bytes(data))
        self.logger.warning(
            "SUA_DU_LIEU file_id=%s cloud=%s", file_id, cloud_name
        )

    def delete_copy(self, file_id: str, cloud_name: str) -> None:
        """Mô phỏng một cloud bị mất bản sao tài liệu."""
        path = self._cipher_path(file_id, cloud_name)
        path.unlink(missing_ok=True)
        self.logger.warning(
            "XOA_BAN_SAO file_id=%s cloud=%s", file_id, cloud_name
        )

    def get_recent_logs(self, limit: int = 20) -> list[str]:
        """Lấy một số dòng log gần nhất để hiển thị trên giao diện."""
        if not self.log_path.exists():
            return []
        try:
            lines = self.log_path.read_text(encoding="utf-8").splitlines()
            return lines[-limit:][::-1]
        except OSError:
            return []
